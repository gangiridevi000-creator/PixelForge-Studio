package com.pixelforge.studio

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.OutputStream

private val bg = Color(0xFF090B10)
private val panel = Color(0xFF151923)
private val accent = Color(0xFF9B7BFF)
private val muted = Color(0xFF9299A8)

data class Preset(val name: String, val saturation: Float, val contrast: Float, val warmth: Float = 0f)

private val presets = listOf(
    Preset("Original", 1f, 1f),
    Preset("Vivid", 1.45f, 1.12f),
    Preset("Cinema", .82f, 1.28f, -.04f),
    Preset("Vintage", .72f, 1.08f, .12f),
    Preset("Warm", 1.08f, 1.05f, .20f),
    Preset("Cool", .95f, 1.08f, -.18f),
    Preset("Fade", .72f, .88f, .04f),
    Preset("Noir", 0f, 1.35f)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PixelForgeApp() }
    }
}

@Composable
fun PixelForgeApp() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf("Photo") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var selectedPreset by remember { mutableStateOf(presets.first()) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        imageUri = uri
        bitmap = uri?.let { context.contentResolver.openInputStream(it)?.use(BitmapFactory::decodeStream) }
        selectedPreset = presets.first()
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { videoUri = it }

    MaterialTheme(colorScheme = darkColorScheme(
        background = bg, surface = panel, primary = accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = bg,
            bottomBar = {
                NavigationBar(containerColor = panel, contentColor = Color.White) {
                    listOf("Photo", "Video", "AI Tools").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    when (tab) {
                                        "Photo" -> Icons.Default.Photo
                                        "Video" -> Icons.Default.Movie
                                        else -> Icons.Default.AutoAwesome
                                    }, contentDescription = tab
                                )
                            },
                            label = { Text(tab) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = accent, selectedTextColor = accent,
                                indicatorColor = accent.copy(alpha = .16f),
                                unselectedIconColor = muted, unselectedTextColor = muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 18.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("PIXELFORGE", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("Studio", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Surface(shape = CircleShape, color = panel) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.HighQuality, null, tint = accent, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("HD EDITOR", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                when (selectedTab) {
                    "Photo" -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Photo editor", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { imagePicker.launch("image/*") }) {
                                Icon(Icons.Default.AddPhotoAlternate, null)
                                Spacer(Modifier.width(5.dp)); Text("Import")
                            }
                        }
                        Box(
                            Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(22.dp))
                                .background(panel).border(1.dp, Color.White.copy(.06f), RoundedCornerShape(22.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap!!.asImageBitmap(),
                                    contentDescription = "Photo preview",
                                    modifier = Modifier.fillMaxSize().padding(8.dp),
                                    colorFilter = ColorFilter.colorMatrix(
                                        ComposeColorMatrix(makeMatrix(selectedPreset, brightness, contrast))
                                    )
                                )
                            } else {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.AddPhotoAlternate, null, tint = accent, modifier = Modifier.size(48.dp))
                                    Spacer(Modifier.height(10.dp))
                                    Text("Your creative canvas", fontWeight = FontWeight.Bold)
                                    Text("Import a photo to start editing", color = muted, fontSize = 13.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        SectionTitle("Modern filters", "8 looks")
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            presets.forEach { preset ->
                                Column(
                                    Modifier.width(82.dp).clip(RoundedCornerShape(14.dp))
                                        .background(if (selectedPreset == preset) accent.copy(.18f) else panel)
                                        .border(1.dp, if (selectedPreset == preset) accent else Color.Transparent, RoundedCornerShape(14.dp))
                                        .clickable { selectedPreset = preset }.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(10.dp))
                                        .background(filterSwatch(preset)), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.FilterVintage, null, tint = Color.White)
                                    }
                                    Spacer(Modifier.height(7.dp))
                                    Text(preset.name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        SectionTitle("Fine tune", "Adjust")
                        Adjustment("Brightness", brightness, -0.5f, 0.5f) { brightness = it }
                        Adjustment("Contrast", contrast, 0.5f, 1.8f) { contrast = it }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = {
                                selectedPreset = presets.first(); brightness = 0f; contrast = 1f
                            }, modifier = Modifier.weight(1f)) { Text("Reset") }
                            Button(
                                onClick = {
                                    val source = bitmap
                                    if (source == null) Toast.makeText(context, "Import a photo first", Toast.LENGTH_SHORT).show()
                                    else {
                                        val edited = applyFilter(source, selectedPreset, brightness, contrast)
                                        saveBitmap(context, edited)
                                        Toast.makeText(context, "Saved to Pictures/PixelForge", Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = accent)
                            ) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("Save HD") }
                        }
                    }
                    "Video" -> {
                        SectionTitle("Video creator", "Studio")
                        Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(22.dp)).background(panel), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Movie, null, tint = accent, modifier = Modifier.size(48.dp))
                                Text(if (videoUri == null) "Create your next video" else "Video selected", fontWeight = FontWeight.Bold)
                                Text("Import a clip to begin", color = muted, fontSize = 13.sp)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                            Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(8.dp)); Text("Import video")
                        }
                        Spacer(Modifier.height(12.dp))
                        FeatureRow("Trim & arrange clips", "Timeline editing module — next build")
                        FeatureRow("Add music and transitions", "Planned feature")
                        FeatureRow("4K video export", "Requires a video rendering pipeline")
                    }
                    else -> {
                        SectionTitle("AI creative tools", "Coming soon")
                        FeatureRow("AI photo enhancement", "Connect an image enhancement model/API")
                        FeatureRow("Background replacement", "Subject segmentation + background compositing")
                        FeatureRow("Location replacement", "Replace the scene background with a new setting")
                        FeatureRow("One-tap portrait retouch", "Planned feature")
                        Text("These tools are shown as product-ready entry points; AI processing is not connected in this starter build.",
                            color = muted, fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp))
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text("PIXELFORGE STUDIO  •  VERSION 1.0", color = muted, fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 18.dp))
            }
        }
    }
}

@Composable
fun SectionTitle(title: String, trailing: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(trailing, color = muted, fontSize = 11.sp)
    }
}

@Composable
fun Adjustment(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row {
            Text(label, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(String.format("%.2f", value), color = muted, fontSize = 12.sp)
        }
        Slider(value = value, onValueChange = onChange, valueRange = min..max,
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
    }
}

@Composable
fun FeatureRow(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).clip(RoundedCornerShape(14.dp)).background(panel).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.AutoAwesome, null, tint = accent)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = muted, fontSize = 11.sp)
        }
    }
}

fun filterSwatch(p: Preset): Color = when (p.name) {
    "Vivid" -> Color(0xFFED795D)
    "Cinema" -> Color(0xFF526A83)
    "Vintage" -> Color(0xFFB98A58)
    "Warm" -> Color(0xFFE9A15D)
    "Cool" -> Color(0xFF6D9BBE)
    "Fade" -> Color(0xFFB4A9A0)
    "Noir" -> Color(0xFF41434B)
    else -> Color(0xFF737B8C)
}

fun makeMatrix(p: Preset, brightness: Float, contrast: Float): FloatArray {
    val sat = p.saturation
    val c = p.contrast * contrast
    val b = (brightness + p.warmth * .12f) * 255f
    val sr = (1 - sat) * .213f
    val sg = (1 - sat) * .715f
    val sb = (1 - sat) * .072f
    return floatArrayOf(
        (sr + sat) * c, sg * c, sb * c, 0f, b + p.warmth * 18f,
        sr * c, (sg + sat) * c, sb * c, 0f, b,
        sr * c, sg * c, (sb + sat) * c, 0f, b - p.warmth * 12f,
        0f, 0f, 0f, 1f, 0f
    )
}

fun applyFilter(source: Bitmap, preset: Preset, brightness: Float, contrast: Float): Bitmap {
    val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(output)
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    paint.colorFilter = ColorMatrixColorFilter(ColorMatrix(makeMatrix(preset, brightness, contrast)))
    canvas.drawBitmap(source, 0f, 0f, paint)
    return output
}

fun saveBitmap(context: android.content.Context, bitmap: Bitmap) {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "PixelForge_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PixelForge")
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("Unable to create image")
    context.contentResolver.openOutputStream(uri)?.use { out: OutputStream ->
        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
    }
}
