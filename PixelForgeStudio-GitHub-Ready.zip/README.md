# PixelForge Studio

A GitHub-ready Android Studio starter for a modern dark-theme photo and video editing app.

## Included in this starter
- Jetpack Compose Android app UI
- Dark professional interface
- Photo import from device gallery
- 8 modern photo looks: Original, Vivid, Cinema, Vintage, Warm, Cool, Fade, Noir
- Brightness and contrast controls
- HD/JPEG photo export to `Pictures/PixelForge`
- Video import entry point
- AI tools screen with clearly marked integration points

## Not yet connected
This is an MVP starter, not a finished CapCut/Lightroom replacement. Video trimming, timeline rendering, 4K video encoding, AI enhancement, background segmentation/replacement, and location-scene generation require additional media-processing and/or AI services. The UI labels these as planned modules rather than pretending they already work.

## Build
1. Install Android Studio (Hedgehog or newer) and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Run on an Android 8.0+ device or emulator.

## GitHub
Create a new empty GitHub repository, then run:

```bash
git init
git add .
git commit -m "Initial PixelForge Studio Android app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/PixelForgeStudio.git
git push -u origin main
```

## Suggested next modules
- Video: AndroidX Media3 Transformer for trim, crop, transitions and export.
- 4K: resolution-aware rendering with device capability checks and export progress.
- AI enhancement/background replacement: connect a trusted inference API or on-device model.
- Add automated tests for filter matrices and export behavior.

## License
MIT — add your preferred license before publishing.
